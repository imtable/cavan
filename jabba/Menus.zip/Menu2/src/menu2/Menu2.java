/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package menu2;

import java.util.Scanner;

/**
 *
 * @author CI20250986
 */
public class Menu2 {

  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    int answer;
    double input;
    double result;

    System.out.println("Please choose an option:");
    System.out.println("1) C->F");
    System.out.println("2) F->C");
    System.out.println("3) Exit");
    System.out.print("Please enter option: ");

    Scanner s = new Scanner(System.in);
    answer = s.nextInt();

    if (answer == 1) {
      System.out.print("Please enter Celsius value: ");
      input = s.nextDouble();
      result = 1.8 * input + 32;
      System.out.println("in F it would be: " + result);
    }
    if (answer == 2) {
      System.out.print("Please enter F value: ");
      input = s.nextDouble();
      result = (input - 32) / 9 * 5;
      System.out.println("in C it would be: " + result);
    }
    if (answer == 3) {
      System.out.println("exiting..");
    }
    if (answer > 3 || answer < 1) {
      System.out.println("Wrong decision, BOOM!");
    }
  }
}
